import React from 'react';
import { View, Image, Text, StyleSheet } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Rasm qo'shish misoli</Text>
      <Image
        source={{
          uri: 'https://a.allegroimg.com/s720/113e97/52bfdb294012a553db3c68d4b995/LED-RAMBIT-SPINNER-nowosc-SWIECACY-KARAMBIT-fidget',
        }}
        style={styles.image}
      />
      <Text>hulas men mobilchiman</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  text: {
    fontSize: 18,
    marginBottom: 20,
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 10,
  },
});
